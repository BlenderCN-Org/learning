/*******************************************************************************
 * Application entry
 * 
 * @generated Tizen Web UI Builder
 * @attribute user, editable
 *******************************************************************************
*/

_app.prototype.init = function() {
	// TODO:: Do your app initialization job
};
