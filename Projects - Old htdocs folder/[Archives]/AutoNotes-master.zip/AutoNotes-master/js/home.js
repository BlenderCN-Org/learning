$(function() {

	$('#header').click(function() {
		location.href = 'showNotes.html'
	});
})