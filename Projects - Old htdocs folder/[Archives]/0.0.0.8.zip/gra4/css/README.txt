custom.css from this directory would be loadad the last, 
so you can overwrite styles of the social pages.