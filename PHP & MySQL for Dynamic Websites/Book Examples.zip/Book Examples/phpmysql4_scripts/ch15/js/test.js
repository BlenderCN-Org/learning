// Script 15.2 - test.js
// This script is included by test.html.
// This script just creates an alert to test jQuery.

// Do something when the document is ready:
$(function() {
	
	// Alert!
	alert('Ready!');
	
});