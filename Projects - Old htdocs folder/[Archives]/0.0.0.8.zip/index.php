<?php
	require_once('common.php');
	checkDirsWritable();
	checkUser();
	header("Location: gra4");	
?>

