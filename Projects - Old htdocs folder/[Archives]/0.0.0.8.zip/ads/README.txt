Files *.html are copies of the *.txt files. The copy happens if corresponding *.html file does not exist. 
We do it to make sure your custom ads (*.html) are not overwritten during the upgrade.
Replace the content of the *.html file with your ads. 
If you don't want ad in a particular place of your pages - leave *.html file empty.
