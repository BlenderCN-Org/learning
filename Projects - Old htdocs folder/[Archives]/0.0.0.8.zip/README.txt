Big social networks put plenty of websites out of business - anyone can create a group, say, on Facebook, and it's much easier than to build and support whole website. 
Now we want to get web-masters back into the game, arming them with the same functionality major social networks have.

The Micro is the simplest GRA4-powered Social Network. It can run on any PHP hosting (including free ones), and does not even require a database server.

If you want to try Micro GRA4 Social Network - use GRA4-enabled free hosting at
http://ucq.me ('You seek me')

Before you install the Micro, please make sure you are installing the newest version: 
http://gra4.com/file/group/97/all

GRA4 Micro Installation

Copy all files (including sub-folders) from micro/ to some folder on your hosting.
For example: public_html/micro 
Your Micro website will be visible at http://yourserver.com/micro

Navigate your browser to http://yourserver.com/micro, register the admin user.

You done ! Now you have full-blown social network on your hosting =)

GRA4 Micro Upgrade
It's safe to just copy new version over the old one.

If you want to monetize your traffic, use the admin interface to place your ad codes.

Get new versions, updates, and support at http://gra4.com/groups/profile/97/gra4-webmasters-micro

Read more at http://gra4.com/wiki