var data = [
    {'name': 'snow white and the seven dwarfs'},
    {'name': 'the last of the mohicans'}
];

// Render
$(document).ready( function () {
    Tempo.prepare('list').render(data);
});