<?php /* Smarty version 2.6.26, created on 2014-03-11 21:25:42
         compiled from file:style/default/templates/menu_main.tpl.html */ ?>
<div id="header">
<ul id="mainmenu" style="display: inline-block;">
	<li><a href="overview.php" <?php echo $this->_tpl_vars['overview']; ?>
><?php echo $this->_tpl_vars['admin_mainmenu_overview']; ?>
</a></li>
	<li><a href="settings.php"<?php echo $this->_tpl_vars['settings']; ?>
><?php echo $this->_tpl_vars['admin_mainmenu_settings']; ?>
</a></li>
	<li><a href="modules.php"<?php echo $this->_tpl_vars['modules']; ?>
><?php echo $this->_tpl_vars['admin_mainmenu_modules']; ?>
</a></li>
    <li><a href="users.php"<?php echo $this->_tpl_vars['users']; ?>
><?php echo $this->_tpl_vars['admin_mainmenu_users']; ?>
</a></li>
    <li><a href="registration.php"<?php echo $this->_tpl_vars['registration']; ?>
><?php echo $this->_tpl_vars['admin_mainmenu_registration']; ?>
</a></li>
    <li><a href="round_mail.php"<?php echo $this->_tpl_vars['round_mail']; ?>
><?php echo $this->_tpl_vars['admin_mainmenu_round_mail']; ?>
</a></li>
    <!--<li><a href="opencunity.php"<?php echo $this->_tpl_vars['opencunity']; ?>
><?php echo $this->_tpl_vars['admin_mainmenu_opencunity']; ?>
</a></li>-->
	<li><a href="../index.php"><?php echo $this->_tpl_vars['admin_mainmenu_home']; ?>
</a></li>
</ul>
</div>