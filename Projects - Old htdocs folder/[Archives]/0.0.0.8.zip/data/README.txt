Make sure your files have appropriate attributes, 
or they will be visible over the Internet