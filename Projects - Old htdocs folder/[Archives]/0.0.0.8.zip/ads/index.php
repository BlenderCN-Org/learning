<?php
//visitors not suppose to be here
	header("Location: ../gra4/");	
?>

