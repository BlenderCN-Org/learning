<?php

class CunityUsers {
	
	private $cunity = null;
	
	public function CunityUsers(Cunity $cunity){
		$this->cunity = $cunity;
	}
}

?>