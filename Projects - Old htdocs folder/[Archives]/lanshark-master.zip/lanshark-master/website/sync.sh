rsync -v -r -e 'ssh' htdocs/ 29a.ch:/home/lanshark/htdocs
