<?php /* Smarty version 2.6.26, created on 2014-03-11 21:25:42
         compiled from file:style/default/templates/overall_footer.tpl.html */ ?>
	</div>
</div>

		<div class="clear"></div>
		<div class="footer_spacer">&nbsp;</div>
	</div>

<div id="overall_footer">
<div style="float: left; margin: 10px;">
<img src="style/default/img/<?php echo $this->_tpl_vars['LANG']; ?>
.png" style="display: inline-block; vertical-align: middle;"/>
<select style="display: inline-block; vertical-align: middle; width: 100px;" onchange="location.href='index.php?setlang='+this.value+''">
    <option value="en" <?php echo $this->_tpl_vars['ENGISH']; ?>
><?php echo $this->_tpl_vars['admin_settings_language_english']; ?>
</option>
    <option value="de" <?php echo $this->_tpl_vars['GERMAN']; ?>
><?php echo $this->_tpl_vars['admin_settings_language_german']; ?>
</option>
</select>
</div>
	<div class="padder footer_inner">Powered by <a href="http://www.cunity.net">CUNITY&reg;</a>
 - Copyright &copy; 2011 by Smart In Media GmbH &amp; Co. KG<br>You can download the source code of this website <a href="http://www.cunity.net">here</a></div>

</div>
	

	
</div>
<?php echo $this->_tpl_vars['JSCRIPT_BOTTOM']; ?>


</body>
</html>